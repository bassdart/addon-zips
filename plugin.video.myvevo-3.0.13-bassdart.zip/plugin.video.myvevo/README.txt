plugin.video.myvevo
================

This is a forked version of plugin.video.myvevo from learningit to
re-add compatibility with KODI Jarvis and make inputstream optional.
For both features plugin.video.reddit_viewer and script.module.youtube.dl
are needed and should be installed automatically from the main KODI-Repo
on first usage (if not already installed).
The addon name is not changed (atleast for now) so everytime a new 
version from learningit arrives in the KODI-Repo this addon will be 
overwritten (This will most likely not happen in Jarvis). 
If I have time I will update (my minimal changes, most of the work is
done by learningit) the fork if a new version comes available.

Kodi Addon for VEVO

Version 3.0.12 use inputstream.adaptive for hls
Version 3.0.11 fix for videos without MPD manifest
Version 3.0.10 Butcher job for no account present.
Version 3.0.9 changes to API and website
Version 3.0.8 Krypton or above needed. Added mpd support thru inputstream.adaptive
Version 3.0.7 m3u8 version fix
Version 3.0.6 auth fix
Version 3.0.5 fix playlists, remove live channels, fix navigation
V3.0.4 add Get Related Videos
V3.0.3 improve add to library
V3.0.2 Added initial version of Add to Library
V3.0.1 Isengard version